// RF69.h
// Author: Mike McCauley (mikem@airspayce.com)
// Copyright (C) 2014 Mike McCauley
// $Id: RF69.h,v 1.3 2014/04/04 05:45:58 mikem Exp mikem $
//
/// \mainpage RF69 library for Arduino
///
/// \par END OF LIFE NOTICE
///
/// This RF69 library has now been superceded by the RadioHead 
/// library http://www.airspayce.com/mikem/arduino/RadioHead
/// RadioHead and its RH_RF69 driver provides all the features supported by RF69, and much more
/// besides, including Reliable Datagrams, Addressing, Routing and Meshes. All the platforms that
/// RF69 supported are also supported by RadioHead.
///
/// This library will no longer be maintained or updated, but we will continue to publish
/// it for the benefit of the the community, and you may continue to use it within the terms of
/// the license. Nevertheless we recommend upgrading to RadioHead where
/// possible.
///
/// This is the Arduino RF69 library.
/// It provides an object-oriented interface for sending and receiving data messages with Hope-RF
/// RF69B based radio modules, such as the RFM69 module, (as used on the excellent Moteino and Moteino-USB 
/// boards from LowPowerLab http://lowpowerlab.com/moteino/ )
/// and compatible chips and modules such as RFM69W, RFM69HW, RFM69CW, RFM69HCW (Semtech SX1231, SX1231H)
/// The RFM69 device is described in http://www.hoperf.cn/upload/rf/RFM69-V1.3.pdf
/// and http://www.hoperf.com/upload/rfchip/RF69-V1.2.pdf
///
/// The Hope-RF (http://www.hoperf.com) RF69 is a low-cost ISM transceiver
/// chip. It supports FSK, GFSK, OOK over a wide range of frequencies and
/// programmable data rates. It also suports AES encryption of up to 64 octets
/// of payload It is available prepackaged on modules such as the RFM69W. And
/// such modules can be prepacked on processor boards such as the Moteino from
/// LowPowerLabs (which is what we used to develop the RF69 library)
///
/// This library provides functions for sending and receiving messages of up
/// to 60 octets on any frequency supported by the RF69, in a range of
/// predefined data rates and frequency deviations.  Frequency can be set with
/// 61Hz precision to any frequency from 240.0MHz to 960.0MHz.
///
/// Up to 2 RF69B modules can be connected to an Arduino (3 on a Mega),
/// permitting the construction of translators and frequency changers, etc.
///
/// This library provides classes for 
/// - RF69: unaddressed, unreliable messages
///
/// Coming soon: classes for datagrams, reliable datagrams, routers and meshes
///
/// The following modulation types are suppported with a range of modem configurations for 
/// common data rates and frequency deviations:
/// - GFSK Gaussian Frequency Shift Keying
/// - FSK Frequency Shift Keying
///
/// Support for other RF69 features such as on-chip temperature measurement, 
/// transmitter power control etc is also provided.
///
/// The latest version of this documentation can be downloaded from 
/// http://www.airspayce.com/mikem/arduino/RF69
///
/// Example Arduino programs are included to show the main modes of use.
///
/// The version of the package that this documentation refers to can be downloaded 
/// from http://www.airspayce.com/mikem/arduino/RF69/RF69-1.3.zip
/// You can find the latest version at http://www.airspayce.com/mikem/arduino/RF69
///
/// Tested on USB-Moteino with arduino-1.0.5
/// on OpenSuSE 13.1
///
/// \par Packet Format
///
/// All messages sent and received by this RF69 library must conform to this packet format:
///
/// - 4 octets PREAMBLE
/// - 2 octets SYNC 0x2d, 0xd4 (configurable, so you can use this as a network filter)
/// - 1 octet RF69 payload length
/// - 4 octets HEADER: (TO, FROM, ID, FLAGS)
/// - 0 to 60 octets DATA 
/// - 2 octets CRC computed with CRC16(IBM), computed on HEADER and DATA
///
/// For technical reasons, the message format is not compatible with the
/// 'HopeRF Radio Transceiver Message Library for Arduino'
/// http://www.airspayce.com/mikem/arduino/HopeRF from the same author. Nor is
/// it compatible with messages sent by 'Virtual Wire'
/// http://www.airspayce.com/mikem/arduino/VirtualWire.pdf also from the same
/// author.  Nor is it compatible with messages sent by 'RF22'
/// http://www.airspayce.com/mikem/arduino/RF22 also from the same author.
///
/// \par Connecting RFM-69 to Arduino
///
/// We tested with Moteino, which is an Arduino Uno compatible with the RFM69W
/// module on-board. Therefore it needs no connections other than the USB
/// programming connection and an antenna to make it work.
///
/// If you have a bare RFM69W that you want to connect to an Arduino, you
/// might use these connections (untested): CAUTION: you must use a 3.3V type
/// Arduino, otherwise you will also need voltage level shifters between the
/// Arduino and the RFM69.  CAUTION, you must also ensure you connect an
/// antenna
/// 
/// \code
///                 Arduino      RFM69W
///                 GND----------GND   (ground in)
///                 3V3----------3.3V  (3.3V in)
/// interrupt 0 pin D2-----------DIO0  (interrupt request out)
///          SS pin D10----------NSS   (chip select in)
///         SCK pin D13----------SCK   (SPI clock in)
///        MOSI pin D11----------MOSI  (SPI Data in)
///        MISO pin D12----------MISO  (SPI Data out)
/// \endcode
///
/// With these connections, you can then use the default constructor RF69().
/// You can override the default settings for the SS pin and the interrupt in
/// the RF69 constructor if you wish to connect the slave select SS to other
/// than the normal one for your Arduino (D10 for Diecimila, Uno etc and D53
/// for Mega) or the interrupt request to other than pin D2 (Caution,
/// different processors have different constraints as to the pins available
/// for interrupts).
///
/// It is possible to have 2 or more radios connected to one Arduino, provided
/// each radio has its own SS and interrupt line (SCK, SDI and SDO are common
/// to all radios)
///
/// Caution: on some Arduinos such as the Mega 2560, if you set the slave
/// select pin to be other than the usual SS pin (D53 on Mega 2560), you may
/// need to set the usual SS pin to be an output to force the Arduino into SPI
/// master mode.
///
/// Caution: Power supply requirements of the RF69 module may be relevant in some circumstances: 
/// RF69 modules are capable of pulling 45mA+ at full power, where Arduino's 3.3V line can
/// give 50mA. You may need to make provision for alternate power supply for
/// the RF69, especially if you wish to use full transmit power, and/or you have
/// other shields demanding power. Inadequate power for the RF69 is likely to cause symptoms such as:
/// -reset's/bootups terminate with "init failed" messages
/// -random termination of communication after 5-30 packets sent/received
/// -"fake ok" state, where initialization passes fluently, but communication doesn't happen
/// -shields hang Arduino boards, especially during the flashing
/// \par Interrupts
///
/// The RF69 library uses interrupts to react to events in the RF69 module,
/// such as the reception of a new packet, or the completion of transmission
/// of a packet.  The RF69 library interrupt service routine reads status from
/// and writes data to the the RF69 module via the SPI interface. It is very
/// important therefore, that if you are using the RF69 library with another
/// SPI based deviced, that you disable interrupts while you transfer data to
/// and from that other device.  Use cli() to disable interrupts and sei() to
/// reenable them.
///
/// \par Memory
///
/// The RF69 library requires non-trivial amounts of memory. The sample
/// programs above all compile to about 8kbytes each, which will fit in the
/// flash proram memory of most Arduinos. However, the RAM requirements are
/// more critical. Therefore, you should be vary sparing with RAM use in
/// programs that use the RF69 library.
///
/// It is often hard to accurately identify when you are hitting RAM limits on Arduino. 
/// The symptoms can include:
/// - Mysterious crashes and restarts
/// - Changes in behaviour when seemingly unrelated changes are made (such as adding print() statements)
/// - Hanging
/// - Output from Serial.print() not appearing
/// 
/// \par Automatic Frequency Control (AFC)
///
/// The RF69 module is configured by the RF69 library to always use AFC.
///
/// \par Performance
///
/// Some simple speed performance tests have been conducted.
/// In general packet transmission rate will be limited by the modulation scheme.
/// Also, if your code does any slow operations like Serial printing it will also limit performance. 
/// We disabled any printing in the tests below.
/// We tested with RF69::GFSK_Rb250Fd250, which is probably the fastest scheme available.
/// We tested with a 13 octet message length, over a very short distance of 10cm.
///
/// Transmission (no reply) tests with modulation RF69::GFSK_Rb250Fd250 and a 
/// 13 octet message show about 152 messages per second transmitted and received.
///
/// Transmit-and-wait-for-a-reply tests with modulation RF69::GFSK_Rb250Fd250 and a 
/// 13 octet message (send and receive) show about 68 round trips per second.
///
/// \par Installation
///
/// Install in the usual way: unzip the distribution zip file to the libraries
/// sub-folder of your sketchbook. 
///
/// This software is Copyright (C) 2011 Mike McCauley. Use is subject to license
/// conditions. The main licensing options available are GPL V2 or Commercial:
/// 
/// \par Donations
///
/// This library is offered under a free GPL license for those who want to use it that way. 
/// We try hard to keep it up to date, fix bugs
/// and to provide free support. If this library has helped you save time or money, please consider donating at
/// http://www.airspayce.com or here:
///
/// \htmlonly <form action="https://www.paypal.com/cgi-bin/webscr" method="post"><input type="hidden" name="cmd" value="_donations" /> <input type="hidden" name="business" value="mikem@airspayce.com" /> <input type="hidden" name="lc" value="AU" /> <input type="hidden" name="item_name" value="Airspayce" /> <input type="hidden" name="item_number" value="RF69" /> <input type="hidden" name="currency_code" value="USD" /> <input type="hidden" name="bn" value="PP-DonationsBF:btn_donateCC_LG.gif:NonHosted" /> <input type="image" alt="PayPal — The safer, easier way to pay online." name="submit" src="https://www.paypalobjects.com/en_AU/i/btn/btn_donateCC_LG.gif" /> <img alt="" src="https://www.paypalobjects.com/en_AU/i/scr/pixel.gif" width="1" height="1" border="0" /></form> \endhtmlonly
/// 
/// \par Open Source Licensing GPL V2
///
/// This is the appropriate option if you want to share the source code of your
/// application with everyone you distribute it to, and you also want to give them
/// the right to share who uses it. If you wish to use this software under Open
/// Source Licensing, you must contribute all your source code to the open source
/// community in accordance with the GPL Version 2 when your application is
/// distributed. See http://www.gnu.org/copyleft/gpl.html
/// 
/// \par Commercial Licensing
///
/// This is the appropriate option if you are creating proprietary applications
/// and you are not prepared to distribute and share the source code of your
/// application. Contact info@airspayce.com for details.
///
/// \par Revision History
///
/// \version 1.0 Initial release
/// \version 1.1 Fixed some typos with assistance of shorted neuron.
/// \version 1.2 Example programs were omitted
/// \version 1.3 Added End Of Life notice. This library will no longer be maintained 
///                and updated: use RadioHead instead.
///
/// \author  Mike McCauley (mikem@airspayce.com)



#ifndef RF69_h
#define RF69_h

#if ARDUINO >= 100
#include <Arduino.h>
#else
#include <wiring.h>
#include "pins_arduino.h"
#endif

// These defs cause trouble on some versions of Arduino
#undef round
#undef double

// The crystal oscillator frequency of the RF69 module
#define RF69_FXOSC 32000000.0

// The Frequency Synthesizer step = RF69_FXOSC / 2^^19
#define RF69_FSTEP  (RF69_FXOSC / 524288)

// This is the maximum number of interrupts the library can support
// Most Arduinos can handle 2, Megas can handle more
#define RF69_NUM_INTERRUPTS 3

// This is the bit in the SPI address that marks it as a write
#define RF69_SPI_WRITE_MASK 0x80

// Max number of octets the RF69 Rx and Tx FIFOs can hold
#define RF69_FIFO_SIZE 66

// Maximum encryptable payload length the RF69 can support
#define RF69_MAX_ENCRYPTABLE_PAYLOAD_LEN 64

// The length of the headers we add.
// The headers are inside the RF69's payload and are therefore encrypted if encryption is enabled
#define RF69_HEADER_LEN 4

// This is the maximum message length that can be supported by this library. Limited by
// the size of the FIFO, since we are unable to support on-the-fly filling and emptying 
// of the FIFO.
// Can be pre-defined to a smaller size (to save SRAM) prior to including this header
// Here we allow for 4 bytes of address and header and payload to be included in the 64 byte encryption limit.
// the one byte payload length is not encrpyted
#ifndef RF69_MAX_MESSAGE_LEN
#define RF69_MAX_MESSAGE_LEN (RF69_MAX_ENCRYPTABLE_PAYLOAD_LEN - RF69_HEADER_LEN)
#endif

// Keep track of the mode the RF69 is in
#define RF69_MODE_IDLE         0
#define RF69_MODE_RX           1
#define RF69_MODE_TX           2

// This is the default node address,
#define RF69_DEFAULT_NODE_ADDRESS 0

// This address in the TO addreess signifies a broadcast
#define RF69_BROADCAST_ADDRESS 0xff

// Register names
#define RF69_REG_00_FIFO                                 0x00
#define RF69_REG_01_OPMODE                               0x01
#define RF69_REG_02_DATAMODUL                            0x02
#define RF69_REG_03_BITRATEMSB                           0x03
#define RF69_REG_04_BITRATELSB                           0x04
#define RF69_REG_05_FDEVMSB                              0x05
#define RF69_REG_06_FDEVLSB                              0x06
#define RF69_REG_07_FRFMSB                               0x07
#define RF69_REG_08_FRFMID                               0x08
#define RF69_REG_09_FRFLSB                               0x09
#define RF69_REG_0A_OSC1                                 0x0a
#define RF69_REG_0B_AFCCTRL                              0x0b
#define RF69_REG_0C_RESERVED                             0x0c
#define RF69_REG_0D_LISTEN1                              0x0d
#define RF69_REG_0E_LISTEN2                              0x0e
#define RF69_REG_0F_LISTEN3                              0x0f
#define RF69_REG_10_VERSION                              0x10
#define RF69_REG_11_PALEVEL                              0x11
#define RF69_REG_12_PARAMP                               0x12
#define RF69_REG_13_OCP                                  0x13
#define RF69_REG_14_RESERVED                             0x14
#define RF69_REG_15_RESERVED                             0x15
#define RF69_REG_16_RESERVED                             0x16
#define RF69_REG_17_RESERVED                             0x17
#define RF69_REG_18_LNA                                  0x18
#define RF69_REG_19_RXBW                                 0x19
#define RF69_REG_1A_AFCBW                                0x1a
#define RF69_REG_1B_OOKPEAK                              0x1b
#define RF69_REG_1C_OOKAVG                               0x1c
#define RF69_REG_1D_OOKFIX                               0x1d
#define RF69_REG_1E_AFCFEI                               0x1e
#define RF69_REG_1F_AFCMSB                               0x1f
#define RF69_REG_20_AFCLSB                               0x20
#define RF69_REG_21_FEIMSB                               0x21
#define RF69_REG_22_FEILSB                               0x22
#define RF69_REG_23_RSSICONFIG                           0x23
#define RF69_REG_24_RSSIVALUE                            0x24
#define RF69_REG_25_DIOMAPPING1                          0x25
#define RF69_REG_26_DIOMAPPING2                          0x26
#define RF69_REG_27_IRQFLAGS1                            0x27
#define RF69_REG_28_IRQFLAGS2                            0x28
#define RF69_REG_29_RSSITHRESH                           0x29
#define RF69_REG_2A_RXTIMEOUT1                           0x2a
#define RF69_REG_2B_RXTIMEOUT2                           0x2b
#define RF69_REG_2C_PREAMBLEMSB                          0x2c
#define RF69_REG_2D_PREAMBLELSB                          0x2d
#define RF69_REG_2E_SYNCCONFIG                           0x2e
#define RF69_REG_2F_SYNCVALUE1                           0x2f
// another 7 sync word bytes follow, 30 through 36 inclusive
#define RF69_REG_37_PACKETCONFIG1                        0x37
#define RF69_REG_38_PAYLOADLENGTH                        0x38
#define RF69_REG_39_NODEADRS                             0x39
#define RF69_REG_3A_BROADCASTADRS                        0x3a
#define RF69_REG_3B_AUTOMODES                            0x3b
#define RF69_REG_3C_FIFOTHRESH                           0x3c
#define RF69_REG_3D_PACKETCONFIG2                        0x3d
#define RF69_REG_3E_AESKEY1                              0x3e
// Another 15 AES key bytes follow
#define RF69_REG_4E_TEMP1                                0x4e
#define RF69_REG_4F_TEMP2                                0x4f
#define RF69_REG_58_TESTLNA                              0x58
#define RF69_REG_5A_TESTPA1                              0x5a
#define RF69_REG_5C_TSETPA2                              0x5c
#define RF69_REG_6F_TESTDAGC                             0x6f
#define RF69_REG_71_TESTAFC                              0x71

// These register masks etc are named wherever possible
// corresponding to the bit and field names in the RFM69 Manual

// RF69_REG_01_OPMODE
#define RF69_OPMODE_SEQUENCEROFF                         0x80
#define RF69_OPMODE_LISTENON                             0x40
#define RF69_OPMODE_LISTENABORT                          0x20
#define RF69_OPMODE_MODE                                 0x1c
#define RF69_OPMODE_MODE_SLEEP                           0x00
#define RF69_OPMODE_MODE_STDBY                           0x04
#define RF69_OPMODE_MODE_FS                              0x08
#define RF69_OPMODE_MODE_TX                              0x0c
#define RF69_OPMODE_MODE_RX                              0x10

// RF69_REG_02_DATAMODUL
#define RF69_DATAMODUL_DATAMODE                          0x60
#define RF69_DATAMODUL_DATAMODE_PACKET                   0x00
#define RF69_DATAMODUL_DATAMODE_CONT_WITH_SYNC           0x40
#define RF69_DATAMODUL_DATAMODE_CONT_WITHOUT_SYNC        0x60
#define RF69_DATAMODUL_MODULATIONTYPE                    0x18
#define RF69_DATAMODUL_MODULATIONTYPE_FSK                0x00
#define RF69_DATAMODUL_MODULATIONTYPE_OOK                0x08
#define RF69_DATAMODUL_MODULATIONSHAPING                 0x03
#define RF69_DATAMODUL_MODULATIONSHAPING_FSK_NONE        0x00
#define RF69_DATAMODUL_MODULATIONSHAPING_FSK_BT1_0       0x01
#define RF69_DATAMODUL_MODULATIONSHAPING_FSK_BT0_5       0x02
#define RF69_DATAMODUL_MODULATIONSHAPING_FSK_BT0_3       0x03
#define RF69_DATAMODUL_MODULATIONSHAPING_OOK_NONE        0x00
#define RF69_DATAMODUL_MODULATIONSHAPING_OOK_BR          0x01
#define RF69_DATAMODUL_MODULATIONSHAPING_OOK_2BR         0x02

// RF69_REG_11_PALEVEL
#define RF69_PALEVEL_PA0ON                               0x80
#define RF69_PALEVEL_PA1ON                               0x40
#define RF69_PALEVEL_PA2ON                               0x20
#define RF69_PALEVEL_OUTPUTPOWER                         0x1f

// RF69_REG_23_RSSICONFIG
#define RF69_RSSICONFIG_RSSIDONE                         0x02
#define RF69_RSSICONFIG_RSSISTART                        0x01

// RF69_REG_25_DIOMAPPING1
#define RF69_DIOMAPPING1_DIO0MAPPING                     0xc0
#define RF69_DIOMAPPING1_DIO0MAPPING_00                  0x00
#define RF69_DIOMAPPING1_DIO0MAPPING_01                  0x40
#define RF69_DIOMAPPING1_DIO0MAPPING_10                  0x80
#define RF69_DIOMAPPING1_DIO0MAPPING_11                  0xc0

#define RF69_DIOMAPPING1_DIO1MAPPING                     0x30
#define RF69_DIOMAPPING1_DIO1MAPPING_00                  0x00
#define RF69_DIOMAPPING1_DIO1MAPPING_01                  0x10
#define RF69_DIOMAPPING1_DIO1MAPPING_10                  0x20
#define RF69_DIOMAPPING1_DIO1MAPPING_11                  0x30

#define RF69_DIOMAPPING1_DIO2MAPPING                     0x0c
#define RF69_DIOMAPPING1_DIO2MAPPING_00                  0x00
#define RF69_DIOMAPPING1_DIO2MAPPING_01                  0x04
#define RF69_DIOMAPPING1_DIO2MAPPING_10                  0x08
#define RF69_DIOMAPPING1_DIO2MAPPING_11                  0x0c

#define RF69_DIOMAPPING1_DIO3MAPPING                     0x03
#define RF69_DIOMAPPING1_DIO3MAPPING_00                  0x00
#define RF69_DIOMAPPING1_DIO3MAPPING_01                  0x01
#define RF69_DIOMAPPING1_DIO3MAPPING_10                  0x02
#define RF69_DIOMAPPING1_DIO3MAPPING_11                  0x03

// RF69_REG_26_DIOMAPPING2
#define RF69_DIOMAPPING2_DIO4MAPPING                     0xc0
#define RF69_DIOMAPPING2_DIO4MAPPING_00                  0x00
#define RF69_DIOMAPPING2_DIO4MAPPING_01                  0x40
#define RF69_DIOMAPPING2_DIO4MAPPING_10                  0x80
#define RF69_DIOMAPPING2_DIO4MAPPING_11                  0xc0

#define RF69_DIOMAPPING2_DIO5MAPPING                     0x30
#define RF69_DIOMAPPING2_DIO5MAPPING_00                  0x00
#define RF69_DIOMAPPING2_DIO5MAPPING_01                  0x10
#define RF69_DIOMAPPING2_DIO5MAPPING_10                  0x20
#define RF69_DIOMAPPING2_DIO5MAPPING_11                  0x30

#define RF69_DIOMAPPING2_CLKOUT                          0x07
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_                   0x00
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_2                  0x01
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_4                  0x02
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_8                  0x03
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_16                 0x04
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_32                 0x05
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_RC                 0x06
#define RF69_DIOMAPPING2_CLKOUT_FXOSC_OFF                0x07

// RF69_REG_27_IRQFLAGS1
#define RF69_IRQFLAGS1_MODEREADY                         0x80
#define RF69_IRQFLAGS1_RXREADY                           0x40
#define RF69_IRQFLAGS1_TXREADY                           0x20
#define RF69_IRQFLAGS1_PLLLOCK                           0x10
#define RF69_IRQFLAGS1_RSSI                              0x08
#define RF69_IRQFLAGS1_TIMEOUT                           0x04
#define RF69_IRQFLAGS1_AUTOMODE                          0x02
#define RF69_IRQFLAGS1_SYNADDRESSMATCH                   0x01

// RF69_REG_28_IRQFLAGS2
#define RF69_IRQFLAGS2_FIFOFULL                          0x80
#define RF69_IRQFLAGS2_FIFONOTEMPTY                      0x40
#define RF69_IRQFLAGS2_FIFOLEVEL                         0x20
#define RF69_IRQFLAGS2_FIFOOVERRUN                       0x10
#define RF69_IRQFLAGS2_PACKETSENT                        0x08
#define RF69_IRQFLAGS2_PAYLOADREADY                      0x04
#define RF69_IRQFLAGS2_CRCOK                             0x02

// RF69_REG_2E_SYNCCONFIG
#define RF69_SYNCCONFIG_SYNCON                           0x80
#define RF69_SYNCCONFIG_FIFOFILLCONDITION_MANUAL         0x40
#define RF69_SYNCCONFIG_SYNCSIZE                         0x38
#define RF69_SYNCCONFIG_SYNCSIZE_1                       0x00
#define RF69_SYNCCONFIG_SYNCSIZE_2                       0x08
#define RF69_SYNCCONFIG_SYNCSIZE_3                       0x10
#define RF69_SYNCCONFIG_SYNCSIZE_4                       0x18
#define RF69_SYNCCONFIG_SYNCSIZE_5                       0x20
#define RF69_SYNCCONFIG_SYNCSIZE_6                       0x28
#define RF69_SYNCCONFIG_SYNCSIZE_7                       0x30
#define RF69_SYNCCONFIG_SYNCSIZE_8                       0x38
#define RF69_SYNCCONFIG_SYNCSIZE_SYNCTOL                 0x07

// RF69_REG_37_PACKETCONFIG1
#define RF69_PACKETCONFIG1_PACKETFORMAT_VARIABLE         0x80
#define RF69_PACKETCONFIG1_DCFREE                        0x60
#define RF69_PACKETCONFIG1_DCFREE_NONE                   0x00
#define RF69_PACKETCONFIG1_DCFREE_MANCHESTER             0x20
#define RF69_PACKETCONFIG1_DCFREE_WHITENING              0x40
#define RF69_PACKETCONFIG1_DCFREE_RESERVED               0x60
#define RF69_PACKETCONFIG1_CRC_ON                        0x10
#define RF69_PACKETCONFIG1_CRCAUTOCLEAROFF               0x08
#define RF69_PACKETCONFIG1_ADDRESSFILTERING              0x06
#define RF69_PACKETCONFIG1_ADDRESSFILTERING_NONE         0x00
#define RF69_PACKETCONFIG1_ADDRESSFILTERING_NODE         0x02
#define RF69_PACKETCONFIG1_ADDRESSFILTERING_NODE_BC      0x04
#define RF69_PACKETCONFIG1_ADDRESSFILTERING_RESERVED     0x06

// RF69_REG_3C_FIFOTHRESH
#define RF69_FIFOTHRESH_TXSTARTCONDITION_NOTEMPTY        0x80
#define RF69_FIFOTHRESH_FIFOTHRESHOLD                    0x7f

// RF69_REG_3D_PACKETCONFIG2
#define RF69_PACKETCONFIG2_INTERPACKETRXDELAY            0xf0
#define RF69_PACKETCONFIG2_RESTARTRX                     0x04
#define RF69_PACKETCONFIG2_AUTORXRESTARTON               0x02
#define RF69_PACKETCONFIG2_AESON                         0x01

// RF69_REG_4E_TEMP1
#define RF69_TEMP1_TEMPMEASSTART                         0x08
#define RF69_TEMP1_TEMPMEASRUNNING                       0x04

// RF69_REG_6F_TESTDAGC
#define RF69_TESTDAGC_CONTINUOUSDAGC_NORMAL              0x00
#define RF69_TESTDAGC_CONTINUOUSDAGC_IMPROVED_LOWBETAON  0x20
#define RF69_TESTDAGC_CONTINUOUSDAGC_IMPROVED_LOWBETAOFF 0x30

// Define this to include Serial printing in diagnostic routines
#define RF69_HAVE_SERIAL

#include <GenericSPI.h>
#include <HardwareSPI.h>

/////////////////////////////////////////////////////////////////////
/// \class RF69 RF69.h <RF69.h>
/// \brief Send and receive unaddressed, unreliable datagrams.
///
/// This base class provides basic functions for sending and receiving unaddressed, 
/// unreliable datagrams of arbitrary length to 64 octets per packet.
///
/// Subclasses may use this class to implement reliable, addressed datagrams and streams, 
/// mesh routers, repeaters, translators etc.
///
/// Naturally, for any 2 radios to communicate that must be configured to use the same frequency and 
/// modulation scheme.
class RF69
{
public:

    /// \brief Defines register values for a set of modem configuration registers
    ///
    /// Defines register values for a set of modem configuration registers
    /// that can be passed to setModemRegisters() if none of the choices in
    /// ModemConfigChoice suit your need setModemRegisters() writes the
    /// register values from this structure to the appropriate RF69 registers
    /// to set the desired modulation type, data rate and deviation/bandwidth.
    typedef struct
    {
	uint8_t    reg_02;   ///< Value for register RF69_REG_02_DATAMODUL
	uint8_t    reg_03;   ///< Value for register RF69_REG_03_BITRATEMSB
	uint8_t    reg_04;   ///< Value for register RF69_REG_04_BITRATELSB
	uint8_t    reg_05;   ///< Value for register RF69_REG_05_FDEVMSB
	uint8_t    reg_06;   ///< Value for register RF69_REG_06_FDEVLSB
	uint8_t    reg_19;   ///< Value for register RF69_REG_19_RXBW
	uint8_t    reg_37;   ///< Value for register RF69_REG_37_PACKETCONFIG1
    } ModemConfig;
  
    /// Choices for setModemConfig() for a selected subset of common
    /// modulation types, and data rates. If you need another configuration,
    /// use the register calculator.  and call setModemRegisters() with your
    /// desired settings.  
    /// These are indexes into MODEM_CONFIG_TABLE
    typedef enum
    {
	FSK_Rb2Fd5 = 0,	   ///< FSK, No Manchester, Rb = 2kbs,    Fd = 5kHz
	FSK_Rb2_4Fd2_4,    ///< FSK, No Manchester, Rb = 2.4kbs,  Fd = 2.4kHz
	FSK_Rb4_8Fd4_8,    ///< FSK, No Manchester, Rb = 4.8kbs,  Fd = 4.8kHz
	FSK_Rb9_6Fd9_6,    ///< FSK, No Manchester, Rb = 9.6kbs,  Fd = 9.6kHz
	FSK_Rb19_2Fd19_2,  ///< FSK, No Manchester, Rb = 19.2kbs, Fd = 19.2kHz
	FSK_Rb38_4Fd38_4,  ///< FSK, No Manchester, Rb = 38.4kbs, Fd = 38.4kHz
	FSK_Rb57_6Fd120,   ///< FSK, No Manchester, Rb = 57.6kbs, Fd = 120kHz
	FSK_Rb125Fd125,    ///< FSK, No Manchester, Rb = 125kbs,  Fd = 125kHz
	FSK_Rb250Fd250,    ///< FSK, No Manchester, Rb = 250kbs,  Fd = 250kHz
	FSK_Rb55555Fd50,   ///< FSK, No Manchester, Rb = 55555kbs,Fd = 50kHz for RFM69 lib compatibility
	FSK_Rb_512Fd2_5,   ///< FSK, No Manchester, Rb = 512bs,   Fd = 2.5kHz for POCSAG compatibility

	GFSK_Rb2Fd5,	    ///< GFSK, No Manchester, Rb = 2kbs,    Fd = 5kHz
	GFSK_Rb2_4Fd2_4,    ///< GFSK, No Manchester, Rb = 2.4kbs,  Fd = 2.4kHz
	GFSK_Rb4_8Fd4_8,    ///< GFSK, No Manchester, Rb = 4.8kbs,  Fd = 4.8kHz
	GFSK_Rb9_6Fd9_6,    ///< GFSK, No Manchester, Rb = 9.6kbs,  Fd = 9.6kHz
	GFSK_Rb19_2Fd19_2,  ///< GFSK, No Manchester, Rb = 19.2kbs, Fd = 19.2kHz
	GFSK_Rb38_4Fd38_4,  ///< GFSK, No Manchester, Rb = 38.4kbs, Fd = 38.4kHz
	GFSK_Rb57_6Fd120,   ///< GFSK, No Manchester, Rb = 57.6kbs, Fd = 120kHz
	GFSK_Rb125Fd125,    ///< GFSK, No Manchester, Rb = 125kbs,  Fd = 125kHz
	GFSK_Rb250Fd250,    ///< GFSK, No Manchester, Rb = 250kbs,  Fd = 250kHz
	GFSK_Rb55555Fd50,   ///< GFSK, No Manchester, Rb = 55555kbs,Fd = 50kHz

//	OOK_Rb1_2Bw75,       ///< OOK, No Manchester, Rb = 1.2kbs,  Rx Bandwidth = 75kHz. Not reliable: do not use

    } ModemConfigChoice;

    /// Constructor. You can have multiple instances, but each instance must have its own
    /// interrupt and slave select pin. After constructing, you must call init() to initialise the interface
    /// and the radio module
    /// \param[in] slaveSelectPin the Arduino pin number of the output to use to select the RF69 before
    /// accessing it. Defaults to the normal SS pin for your Arduino (D10 for Diecimila, Uno etc, D53 for Mega)
    /// \param[in] interrupt The interrupt number to use. 0 - 2. Default is interrupt 0 (Usually Arduino input pin 2)
    /// \param[in] spi Pointer to the SPI interface object to use. 
    ///                Defaults to the standard Arduino hardware SPI interface
    RF69(uint8_t slaveSelectPin = SS, uint8_t interrupt = 0, GenericSPIClass *spi = &Hardware_spi);
  
    /// Initialises this instance and the radio module connected to it.
    /// The following steps are taken:
    /// - Initialise the slave select pin and the SPI interface library
    /// - Software reset the RF69 module
    /// - Checks the connected RF69 module can be communicated
    /// - Attaches an interrupt handler
    /// - Configures the RF69 module
    /// - Sets the frequency to 434.0 MHz
    /// - Sets the modem data rate to FSK_Rb2Fd5
    /// \return  true if everything was successful
    boolean        init();

    /// Issues a software reset to the 
    /// RF69 module. Blocks for 1ms to ensure the reset is complete.
    void           reset();

    /// Reads a single register from the RF69
    /// \param[in] reg Register number, one of RF69_REG_*
    /// \return The value of the register
    uint8_t        spiRead(uint8_t reg);

    /// Writes a single byte to the RF69 
    /// \param[in] reg Register number, one of RF69_REG_*
    /// \param[in] val The value to write
    void           spiWrite(uint8_t reg, uint8_t val);

    /// Reads a number of consecutive registers from the RF69 using burst read mode
    /// \param[in] reg Register number of the first register, one of RF69_REG_*
    /// \param[in] dest Array to write the register values to. Must be at least len bytes
    /// \param[in] len Number of bytes to read
    void           spiBurstRead(uint8_t reg, uint8_t* dest, uint8_t len);

    /// Write a number of consecutive registers using burst write mode
    /// \param[in] reg Register number of the first register, one of RF69_REG_*
    /// \param[in] src Array of new register values to write. Must be at least len bytes
    /// \param[in] len Number of bytes to write
    void           spiBurstWrite(uint8_t reg, const uint8_t* src, uint8_t len);

    /// Reads the on-chip temperature sensor.
    /// The RF69 must be in Idle mode (= RF69 Standby) to measure temperature.
    /// The measurement is uncalibrated and without calibration, you can expectit to be far from
    /// correct.
    /// \return The measured temperature, in degrees C from -40 to 85 (uncalibrated)
    int8_t        temperatureRead();   

    /// Sets the transmitter and receiver 
    /// centre frequency
    /// \param[in] centre Frequency in MHz. 240.0 to 960.0. Caution, RF69 comes in several
    /// different frequency ranges, and setting a frequency outside that range of your radio will probably not work
    /// \param[in] afcPullInRange Not used
    /// \return true if the selected frquency centre is within range
    boolean        setFrequency(float centre, float afcPullInRange = 0.05);

    /// Reads and returns the current RSSI value. 
    /// Causes the current signal strength to be measured and returned
    /// If you want to find the RSSI
    /// of the last received message, use lastRssi() instead.
    /// \return The current RSSI value on units of 0.5dB.
    int8_t        rssiRead();

    /// Sets the parameters for the RF69 OPMODE.
    /// This is a low level device access funciton, and should not normally ned to be used by user code. 
    /// Instead can use stModeRx(), setModeTx(), setModeIdle()
    /// \param[in] mode RF69 OPMODE to set, one of RF69_OPMODE_MODE_*.
    void           setMode(uint8_t mode);

    /// If current mode is Rx or Tx changes it to Idle. If the transmitter or receiver is running, 
    /// disables them.
    void           setModeIdle();

    /// If current mode is Tx or Idle, changes it to Rx. 
    /// Starts the receiver in the RF69.
    void           setModeRx();

    /// If current mode is Rx or Idle, changes it to Rx. F
    /// Starts the transmitter in the RF69.
    void           setModeTx();

    /// Returns the operating mode of the library.
    /// \return the current mode, one of RF69_MODE_*
    uint8_t        mode();

    /// Sets the transmitter power output level.
    /// Be a good neighbour and set the lowest power level you need.
    /// Caution: legal power limits may apply in certain countries.
    /// After init(), the power will be set to 13dBm.
    /// \param[in] power Transmitter power level in dBm from -18dBm to +13dB (higher powers may
    /// be available depending on which version of RF69 radio you have).
    void           setTxPower(int8_t power);

    /// Sets all the registered required to configure the data modem in the RF69, including the data rate, 
    /// bandwidths etc. You cas use this to configure the modem with custom configurations if none of the 
    /// canned configurations in ModemConfigChoice suit you.
    /// \param[in] config A ModemConfig structure containing values for the modem configuration registers.
    void           setModemRegisters(const ModemConfig* config);

    /// Select one of the predefined modem configurations. If you need a modem configuration not provided 
    /// here, use setModemRegisters() with your own ModemConfig.
    /// \param[in] index The configuration choice.
    /// \return true if index is a valid choice.
    boolean        setModemConfig(ModemConfigChoice index);

    /// Starts the receiver and checks whether a received message is available.
    /// This can be called multiple times in a timeout loop
    /// \return true if a complete, valid message has been received and is able to be retrieved by
    /// recv()
    boolean        available();

    /// Starts the receiver and blocks until a valid received 
    /// message is available.
    void           waitAvailable();

    /// Starts the receiver and blocks until a received message is available or a timeout
    /// \param[in] timeout Maximum time to wait in milliseconds.
    /// \return true if a message is available
    bool           waitAvailableTimeout(uint16_t timeout);

    /// Sets the address of this node. Defaults to 0xFF. Subclasses or the user may want to change this.
    /// This will be used to test the adddress in incoming messages. In non-promiscuous mode,
    /// only messages with a TO header the same as thisAddress or the broadcast addess (0xFF) will be accepted.
    /// In promiscuous mode, all messages will be accepted regardless of the TO header.
    /// In a conventional multinode system, all nodes will have a unique address 
    /// (which you could store in EEPROM).
    /// You would normally set the header FROM address to be the same as thisAddress (though you dont have to, 
    /// allowing the possibilty of address spoofing).
    /// \param[in] thisAddress The address of this node.
    void setThisAddress(uint8_t thisAddress);

    /// Turns the receiver on if it not already on.
    /// If there is a valid message available, copy it to buf and return true
    /// else return false.
    /// If a message is copied, *len is set to the length (Caution, 0 length messages are permitted).
    /// You should be sure to call this function frequently enough to not miss any messages
    /// It is recommended that you call it in your main loop.
    /// \param[in] buf Location to copy the received message
    /// \param[in,out] len Pointer to available space in buf. Set to the actual number of octets copied.
    /// \return true if a valid message was copied to buf
    boolean        recv(uint8_t* buf, uint8_t* len);

    /// Waits until any previous transmit packet is finished being transmitted with waitPacketSent().
    /// Then loads a message into the transmitter and starts the transmitter. Note that a message length
    /// of 0 is NOT permitted. 
    /// \param[in] data Array of data to be sent
    /// \param[in] len Number of bytes of data to send (> 0)
    /// \return true if the message length was valid and it was correctly queued for transmit
    boolean        send(const uint8_t* data, uint8_t len);

    /// Blocks until the RF69 is not in mode RF69_MODE_TX (ie until the RF69 is not transmitting).
    /// This effectively waits until any previous transmit packet is finished being transmitted.
    void           waitPacketSent();
  
    /// Blocks until the RF69 is not in mode RF69_MODE_TX (ie until the RF69 is not transmitting)
    /// or until the timeout occuers, whichever happens first
    /// \param[in] timeout Maximum time to wait in milliseconds.
    /// \return true if the RF69 is not transmitting any more
    bool           waitPacketSent(uint16_t timeout);
  
    /// Tells the receiver to accept messages with any TO address, not just messages
    /// addressed to thisAddress or the broadcast address
    /// \param[in] promiscuous true if you wish to receive messages with any TO address
    void           setPromiscuous(boolean promiscuous);

    /// Returns the TO header of the last received message
    /// \return The TO header
    uint8_t        headerTo();

    /// Returns the FROM header of the last received message
    /// \return The FROM header
    uint8_t        headerFrom();

    /// Returns the ID header of the last received message
    /// \return The ID header
    uint8_t        headerId();

    /// Returns the FLAGS header of the last received message
    /// \return The FLAGS header
    uint8_t        headerFlags();

    /// Returns the most recent RSSI (Receiver Signal Strength Indicator).
    /// Usually it is the RSSI of the last received message, which is measured when the preamble is received.
    /// If you called readRssi() more recently, it will return that more recent value.
    /// \return The most recent RSSI measurement in dBm.
    int8_t        lastRssi();

    /// Prints a data buffer in HEX.
    /// For diagnostic use
    /// \param[in] prompt string to preface the print
    /// \param[in] buf Location of the buffer to print
    /// \param[in] len Length of the buffer in octets.
    static void    printBuffer(const char* prompt, const uint8_t* buf, uint8_t len);

    /// Sets the length of the preamble
    /// in bytes. 
    /// Caution: this should be set to the same 
    /// value on all nodes in your network. Default is 4.
    /// Sets the message preamble length in REG_0?_PREAMBLE?SB
    /// \param[in] bytes Preamble length in bytes.  
    void           setPreambleLength(uint16_t bytes);

    /// Sets the sync words for transmit and receive 
    /// Caution: SyncWords should be set to the same 
    /// value on all nodes in your network. Nodes with different SyncWords set will never receive
    /// each others messages, so different SyncWords can be used to isolate different
    /// networks from each other. Default is { 0x2d, 0xd4 }.
    /// \param[in] syncWords Array of sync words, 1 to 4 octets long. NULL if no sync words to be used.
    /// \param[in] len Number of sync words to set, 1 to 4. 0 if no sync words to be used.
    void           setSyncWords(const uint8_t* syncWords = NULL, uint8_t len = 0);

    /// Enables AES encryption and sets the AES encryption key, used
    /// to encrypt and decrypt all messages. The default is disabled.
    /// \param[in] key The key to use. Must be 16 bytes long. The same key must be installed
    /// in other instances of RF69, otherwise communications will not work correctly. If key is NULL,
    /// encryption is disabled.
    void           setEncryptionKey(uint8_t* key = NULL);

protected:
    /// This is a low level function to handle the interrupts for one instance of RF69.
    /// Called automatically by isr*()
    /// Should not need to be called by user code.
    void           handleInterrupt();

    /// Low level function to read the FIFO and put the received data into the receive buffer
    /// Should not need to be called by user code.
    void           readFifo();

    /// Sets the TO header to be sent in all subsequent messages
    /// \param[in] to The new TO header value
    void           setHeaderTo(uint8_t to);

    /// Sets the FROM header to be sent in all subsequent messages
    /// \param[in] from The new FROM header value
    void           setHeaderFrom(uint8_t from);

    /// Sets the ID header to be sent in all subsequent messages
    /// \param[in] id The new ID header value
    void           setHeaderId(uint8_t id);

    /// Sets the FLAGS header to be sent in all subsequent messages
    /// \param[in] flags The new FLAGS header value
    void           setHeaderFlags(uint8_t flags);

protected:
    GenericSPIClass*    _spi;

    /// Low level interrupt service routine for RF69 connected to interrupt 0
    static void         isr0();

    /// Low level interrupt service routine for RF69 connected to interrupt 1
    static void         isr1();

    /// Low level interrupt service routine for RF69 connected to interrupt 1
    static void         isr2();

    /// Array of instances connected to interrupts 0 and 1
    static RF69*        _RF69ForInterrupt[];

    volatile uint8_t    _mode; // One of RF69_MODE_*

    uint8_t             _idleMode; // The radio mode to use when mode is RF69_MODE_IDLE
    uint8_t             _slaveSelectPin;
    uint8_t             _interrupt;
    uint8_t             _deviceType;

    // These volatile members may get changed in the interrupt service routine
    volatile uint8_t    _bufLen;
    uint8_t             _buf[RF69_MAX_MESSAGE_LEN];

    // This node id
    uint8_t             _thisAddress;
    boolean             _promiscuous;

    // Headers of last received message
    uint8_t             _rxHeaderTo;
    uint8_t             _rxHeaderFrom;
    uint8_t             _rxHeaderId;
    uint8_t             _rxHeaderFlags;

    // Headers of next to transmit message
    uint8_t             _txHeaderTo;
    uint8_t             _txHeaderFrom;
    uint8_t             _txHeaderId;
    uint8_t             _txHeaderFlags;

    volatile boolean    _rxBufValid;

    volatile boolean    _txPacketSent;
  
    volatile uint16_t   _rxBad;
    volatile uint16_t   _rxGood;
    volatile uint16_t   _txGood;

    volatile int8_t     _lastRssi;
};

/// @example rf69_client.ino
/// Example sketch showing how to create a simple messageing client
/// with the RF69 class. RF69 class does not provide for addressing or reliability.
/// It is designed to work with the example rf69_server.
/// Demonstrates the use of AES encrpyion.

/// @example rf69_server.ino
/// Example sketch showing how to create a simple messageing server
/// with the RF69 class. RF69 class does not provide for addressing or reliability.
/// It is designed to work with the example rf69_client
/// Demonstrates the use of AES encrpyion.


#endif
