// HardwareSPI.h
// Author: Mike McCauley (mikem@airspayce.com)
// Copyright (C) 2011 Mike McCauley
// Contributed by Joanna Rutkowska
// $Id: HardwareSPI.cpp,v 1.1 2014/03/31 21:37:42 mikem Exp $

#include "HardwareSPI.h"

// Declare a single instance of the hardware SPI interface class
HardwareSPIClass Hardware_spi;
