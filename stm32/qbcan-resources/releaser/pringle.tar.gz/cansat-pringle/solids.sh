#!/bin/bash

set -euo pipefail

declare -ra solids=( $(
	perl -ne 'print "$1\n" if m{\brender_([\w\d_]+?)_solid\b};' assembly.scad)
)
declare -r solid_dir='solids'
declare -r fn=90

function render_solid {
	local -r name="$1"
	local -r tf="$(mktemp).scad"
	local -r stl="${solid_dir}/${name}.stl"
	local -r png="${solid_dir}/${name}.png"

	(
		printf "mode = 2;\n"
		printf "\$fn = %f;\n" "${fn}"
		printf "render_%s_solid();\n" "${name}"
		printf "\n"
		cat assembly.scad
	) > "${tf}"

	mkdir -p "${solid_dir}"

	if openscad -o "${stl}" "${tf}" && openscad -o "${png}" "${tf}"; then
		return 0
	else
		local -r err="$(mktemp)"
		cp "${tf}" "${err}"
		printf "'%s' failed: %s\n" "${name}" "${err}"
		return 1
	fi
}

function render_individually {
	for solid in "${solids[@]}"; do
		printf "Rendering '%s'...\n" "${solid}"
		render_solid "${solid}"
	done
}

render_individually
