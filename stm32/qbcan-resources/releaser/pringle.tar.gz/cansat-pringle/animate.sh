#!/bin/bash

set -euo pipefail

declare -ri frames=200
declare -ri rate=130
declare -ri fn=90

declare -r video_res='hd720'

function render_frame {
	local -ri f="$1"
	local -r temp="$2"
	local -r camera="$3"
	local -r tf="__tmp-${f}.scad"

	function clean {
		rm -f -- "${tf}"
	}
	trap clean EXIT
	(
		printf "time = (%d / %d);\n" "${f}" "${rate}"
		printf "\$fn = %f;\n" "${fn}"
		printf "\n"
		cat assembly.scad
	) > "${tf}"
	if openscad -o "$(printf "%s/frame-%04d.png" "${temp}" "${f}")" \
		--camera=$camera \
		--projection=perspective \
		--imgsize=2560,1440 \
		"${tf}"; then
		exit 0
	else
		local -r err="$(mktemp)"
		cp "${tf}" "${err}"
		printf "Failed with: ${err}\n"
		exit 1
	fi
}

function render_all {
	local -r temp="$(mktemp -d)"

	local -r out="$1"
	shift
	local -ra args=( "$@" )

	cd "$(dirname "$0")"

	rm -f -- video.mp4

	for ((f=0; f<frames; f++)); do
		printf "%d\n" "$f"
	done | nice xargs -I {} -P10 "$0" render {} "${temp}" "${args[@]}"

	nice ffmpeg -r 24 -i "${temp}/frame-%04d.png" \
		-s "${video_res}" \
		-c:v libx264 \
		-crf "14" \
		-pix_fmt yuv444p \
		-y "${out}.mp4"

	rm -rf -- "${temp}"

#	mpv "${out}.mp4"
}

if (( $# )) && [ "$1" == "render" ]; then
	shift
	printf "  render-frame"
	printf " '%s'" "$@"
	printf "\n"
	render_frame "$@"
else
	render_all "wormdrive" "-45.41,-5.99,225.98,1.10,0.00,354.90,292"
	render_all "all" "-67.02,87.90,150.21,50.80,0.00,314.30,1151.54"
	render_all "below" "3.51,45.60,192.66,161.40,0.00,308.00,680"
fi

