#!/bin/bash

set -euo pipefail

declare -ra shapes=( $(
	perl -ne 'print "$1\n" if m{\brender_([\w\d_]+?)_shape\b};' assembly.scad)
)
declare -r error_margin='1.0'
declare -r path_dir='paths'
declare -r fn=90

function render_all {
	local -r name='all'
	local -r tf="$(mktemp).scad"
	local -r dxf="${path_dir}/${name}.dxf"
	local -r svg="${path_dir}/${name}.svg"

	(
		printf "mode = 1;\n"
		printf "\$fn = %f;\n" "${fn}"
		printf "\n"
		cat assembly.scad
	) > "${tf}"

	mkdir -p "${path_dir}"

	if openscad -o "${svg}" "${tf}" && openscad -o "${dxf}" "${tf}"; then
		return 0
	else
		local -r err="$(mktemp)"
		cp "${tf}" "${err}"
		printf "'%s' failed: %s\n" "${name}" "${err}"
		return 1
	fi
}

function render_shape {
	local -r name="$1"
	local -r tf="$(mktemp).scad"
	local -r dxf="${path_dir}/${name}.dxf"
	local -r svg="${path_dir}/${name}.svg"

	(
		printf "mode = 2;\n"
		printf "\$fn = %f;\n" "${fn}"
		printf "render_%s_shape(%s);\n" "${name}" "${error_margin}"
		printf "\n"
		cat assembly.scad
	) > "${tf}"

	mkdir -p "${path_dir}"

	if openscad -o "${svg}" "${tf}" && openscad -o "${dxf}" "${tf}"; then
		return 0
	else
		local -r err="$(mktemp)"
		cp "${tf}" "${err}"
		printf "'%s' failed: %s\n" "${name}" "${err}"
		return 1
	fi
}

function render_individually {
	for shape in "${shapes[@]}"; do
		printf "Rendering '%s'...\n" "${shape}"
		render_shape "${shape}"
	done
}

render_individually
render_all
